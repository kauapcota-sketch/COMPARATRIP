// PEGAR TODOS OS CARTÕES

let cartoes = document.querySelectorAll(".cartao-destino");

// ANIMAÇÃO DE ENTRADA

cartoes.forEach(function(cartao, indice) {

    cartao.style.opacity = "0";
    cartao.style.transform = "translateY(30px)";

    setTimeout(function() {

        cartao.style.transition = "all 0.8s ease";
        cartao.style.opacity = "1";
        cartao.style.transform = "translateY(0)";

    }, 300 * (indice + 1));

});

// EFEITO NO MENU

let links = document.querySelectorAll(".menu-navegacao a");

links.forEach(function(link) {

    link.addEventListener("mouseenter", function() {
        link.style.transform = "translateY(-3px)";
    });

    link.addEventListener("mouseleave", function() {
        link.style.transform = "translateY(0)";
    });

});

// BOTÃO VOLTAR AO TOPO

let voltarTopo = document.getElementById("voltarTopo");

// MOSTRAR O BOTÃO AO DESCER A PÁGINA

window.addEventListener("scroll", function() {

    if (window.scrollY > 200) {
        voltarTopo.style.display = "block";
    } else {
        voltarTopo.style.display = "none";
    }

});

// VOLTAR PARA O INÍCIO

voltarTopo.addEventListener("click", function() {

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

});